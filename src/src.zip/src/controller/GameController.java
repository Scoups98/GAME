package controller;
import listener.GameListener;
import model.Constant;
import model.PlayerColor;
import model.Chessboard;
import model.ChessboardPoint;
import view.CellComponent;
import view.ElephantChessComponent;
import view.ChessboardComponent;
import view.allcomponent;
import javax.swing.*;
/**
 * Controller is the connection between model and view,
 * when a Controller receive a request from a view, the Controller
 * analyzes and then hands over to the model for processing
 * [in this demo the request methods are onPlayerClickCell() and onPlayerClickChessPiece()]
 *
*/
public class GameController implements GameListener {
    private Chessboard model;
    private ChessboardComponent view;
    private PlayerColor currentPlayer;
    // Record whether there is a selected piece before
    private ChessboardPoint selectedPoint;
    public GameController(ChessboardComponent view, Chessboard model) {
        this.view = view;
        this.model = model;
        this.currentPlayer = PlayerColor.BLUE;

        view.registerController(this);
        initialize();
        view.initiateChessComponent(model);
        view.repaint();
    }

    private void initialize() {
        for (int i = 0; i < Constant.CHESSBOARD_ROW_SIZE.getNum(); i++) {
            for (int j = 0; j < Constant.CHESSBOARD_COL_SIZE.getNum(); j++) {

            }
        }
    }

    // after a valid move swap the player
    private void swapColor() {
        currentPlayer = currentPlayer == PlayerColor.BLUE ? PlayerColor.RED : PlayerColor.BLUE;
    }

    private boolean win() {
        // TODO: Check the board if there is a winner
        return false;
    }


    // click an empty cell
    @Override
    public void onPlayerClickCell(ChessboardPoint point, CellComponent component) {
        if (selectedPoint != null && model.isValidMove(selectedPoint, point)) {
            model.moveChessPiece(selectedPoint, point);
            view.setChessComponentAtGrid(point, view.removeChessComponentAtGrid(selectedPoint));
            selectedPoint = null;
            swapColor();
            view.repaint();
         //   if(component instanceof xianjing){

          //  }
            // TODO: if the chess enter Dens or Traps and so on
        }
    }

    // click a cell with a chess
    @Override
    public void onPlayerClickChessPiece(ChessboardPoint point, allcomponent component) {
        if (selectedPoint == null) {
            if (model.getChessPieceOwner(point).equals(currentPlayer)) {
                selectedPoint = point;
                component.setSelected(true);
                component.repaint();
            }
        } else if (selectedPoint.equals(point)) {
            selectedPoint = null;
            component.setSelected(false);
            component.repaint();
        } else {
            if(model.isValidCapture(point,selectedPoint)){
                model.captureChessPiece(point,selectedPoint);
//                model.getChessPieceOwner(point);
                view.removeChessComponentAtGrid(point);
                view.setChessComponentAtGrid(point,view.removeChessComponentAtGrid(selectedPoint));
                swapColor();
                selectedPoint = null;
//                component.setSelected(false);
                view.repaint();
            }

        }
        // TODO: Implement capture function
    }
public class MyLabel extends JLabel {
        protected int row;
        protected int col;
        public MyLabel(String s,int num){
            super(s,num);
        }
}
 /*   private static boolean occupycamp(MyLabel a, MyLabel b){
        if(b.row == 3 && b.col ==0){//蓝方兽穴所在位置，只有红方动物能进入
            if(b.getColor() == Color.RED){
                //判断是不是红方进入
                return  true;
            }
            else return false;
        }else if(b.row == 3 && b.col ==8){//红方兽穴所在位置
            if(){
                //判断是否蓝方棋子
                return true;
            }
            else return false;
        }
        return true; //如果b不在兽穴则返回真值
    }

  */
}
