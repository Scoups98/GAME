package view;

import model.PlayerColor;

import java.awt.*;

public class shouxue extends allcomponent{
    private PlayerColor owner;
    private boolean selected;
    public shouxue(PlayerColor owner, int size) {
        this.owner = owner;
        this.selected = false;
        setSize(size/2, size/2);
        setLocation(0,0);
        setVisible(true);
    }
    public boolean isSelected() {
        return false;
    }
    public void setSelected(boolean selected) {
        this.selected = false;
    }
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        Font font = new Font("楷体", Font.PLAIN, getWidth() / 3);
        g2.setFont(font);
        g2.setColor(owner.getColor());
        g2.drawString("兽穴", getWidth() / 4, getHeight() * 5 / 8); // FIXME: Use library to find the correct offset.
    }
}