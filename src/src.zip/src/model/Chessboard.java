package model;
/**
 * This class store the real chess information.
 * The Chessboard has 9*7 cells, and each cell has a position for chess
 */
public class Chessboard {
    private Cell[][] grid;
    public Chessboard() {
        this.grid =
                new Cell[Constant.CHESSBOARD_ROW_SIZE.getNum()][Constant.CHESSBOARD_COL_SIZE.getNum()];//19X19

        initGrid();
        initPieces();
    }
    private void initGrid() {
        grid = new Cell[9][7];
        for (int i = 0; i < Constant.CHESSBOARD_ROW_SIZE.getNum(); i++) {
            for (int j = 0; j < Constant.CHESSBOARD_COL_SIZE.getNum(); j++) {
                grid[i][j] = new Cell();   //把棋盘格子分出来
            }
        }
    }
    private void initPieces() {
        grid[0][0].setPiece(new ChessPiece(PlayerColor.BLUE, "lion",7));
        grid[8][6].setPiece(new ChessPiece(PlayerColor.RED, "lion",7));
        grid[2][6].setPiece(new ChessPiece(PlayerColor.BLUE, "xiang",8));
        grid[6][0].setPiece(new ChessPiece(PlayerColor.RED, "xiang",8));
        grid[2][0].setPiece(new ChessPiece(PlayerColor.BLUE, "shu",1));
        grid[6][6].setPiece(new ChessPiece(PlayerColor.RED, "shu",1));
        grid[2][2].setPiece(new ChessPiece(PlayerColor.BLUE, "bao",5));
        grid[6][4].setPiece(new ChessPiece(PlayerColor.RED, "bao",5));
        grid[1][5].setPiece(new ChessPiece(PlayerColor.BLUE, "mao",2));
        grid[7][1].setPiece(new ChessPiece(PlayerColor.RED, "mao",2));
        grid[1][1].setPiece(new ChessPiece(PlayerColor.BLUE, "gou",3));
        grid[7][5].setPiece(new ChessPiece(PlayerColor.RED, "gou",3));
        grid[2][4].setPiece(new ChessPiece(PlayerColor.BLUE, "lang",4));
        grid[6][2].setPiece(new ChessPiece(PlayerColor.RED, "lang",4));
        grid[0][6].setPiece(new ChessPiece(PlayerColor.BLUE, "hu",6));
        grid[8][0].setPiece(new ChessPiece(PlayerColor.RED, "hu",6));
      /*  grid[0][2].setPiece(new ChessPiece(PlayerColor.BLUE,"xianjing",0));
        grid[8][2].setPiece(new ChessPiece(PlayerColor.RED,"xianjing",0));
        grid[0][4].setPiece(new ChessPiece(PlayerColor.BLUE,"xianjing",0));
        grid[8][4].setPiece(new ChessPiece(PlayerColor.RED,"xianjing",0));
        grid[1][3].setPiece(new ChessPiece(PlayerColor.BLUE,"xianjing",0));
        grid[7][3].setPiece(new ChessPiece(PlayerColor.RED,"xianjing",0));
        grid[0][3].setPiece(new ChessPiece(PlayerColor.BLUE,"shouxue",0));
        grid[8][3].setPiece(new ChessPiece(PlayerColor.RED,"shouxue",0));

       */
    }
    public ChessPiece getChessPieceAt(ChessboardPoint point) {
        return getGridAt(point).getPiece();
    }
    public Cell getGridAt(ChessboardPoint point) {
        return grid[point.getRow()][point.getCol()];
    }

    public int calculateDistance(ChessboardPoint src, ChessboardPoint dest) {
        return Math.abs(src.getRow() - dest.getRow()) + Math.abs(src.getCol() - dest.getCol());
    }

    public ChessPiece removeChessPiece(ChessboardPoint point) {
        ChessPiece chessPiece = getChessPieceAt(point);
        getGridAt(point).removePiece();
        return chessPiece;
    }

    public void setChessPiece(ChessboardPoint point, ChessPiece chessPiece) {
        getGridAt(point).setPiece(chessPiece);
    }

    public void moveChessPiece(ChessboardPoint src, ChessboardPoint dest) {
        if (!isValidMove(src, dest)) {
            throw new IllegalArgumentException("Illegal chess move!");
        }
        setChessPiece(dest, removeChessPiece(src));
    }

    public void captureChessPiece(ChessboardPoint src, ChessboardPoint dest) {
//        if (isValidCapture(src, dest)) {
//
//            throw new IllegalArgumentException("Illegal chess capture!");
//        }
        removeChessPiece(dest);
        setChessPiece(dest, getChessPieceAt(src));
        removeChessPiece(src);
    }

    public Cell[][] getGrid() {
        return grid;
    }
    public PlayerColor getChessPieceOwner(ChessboardPoint point) {
        return getGridAt(point).getPiece().getOwner();
    }

    public boolean isValidMove(ChessboardPoint src, ChessboardPoint dest) {
        boolean sc = dest.getCol() == 1 || dest.getCol() == 2 || dest.getCol() == 4 || dest.getCol() == 5;
        boolean sr = dest.getRow() == 3 || dest.getRow() == 4 || dest.getCol() == 5;
        if (getChessPieceAt(src) == null || getChessPieceAt(dest) != null) {
            return false;
        }
        return calculateDistance(src, dest) == 1 &&
                (getChessPieceAt(src).rank == 1 || !(sc && sr));
    }


    public boolean isValidCapture(ChessboardPoint src, ChessboardPoint dest) { //SRC: source; DEST: destination
        if(getChessPieceOwner(src) != getChessPieceOwner(dest)) {
            int srcRank = getChessPieceAt(src).rank;
            int destRank = getChessPieceAt(dest).rank;
            // TODO: 坐标合法？ 判断大小
            if ((getChessPieceAt(src).rank >= getChessPieceAt(dest).rank &&
                    (getChessPieceAt(dest).rank != 1 && getChessPieceAt(src).rank != 8)) ||
                    (getChessPieceAt(src).rank == 1 && getChessPieceAt(dest).rank == 8)) {
                return true;
            } else {                      //上面那里判断象和鼠 && 还是 ||
                return false;
            }
        }
        return false;
    }
}
